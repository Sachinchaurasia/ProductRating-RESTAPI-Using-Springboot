package com.example.product.service;



import com.example.product.dto.ProductRatingResponse;
import com.example.product.entity.Product;
import com.example.product.entity.Rating;
import com.example.product.repository.ProductRepository;
import org.springframework.stereotype.Service;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class ProductServiceImpl implements ProductService {

    private final ProductRepository repository;

    public ProductServiceImpl(ProductRepository repository) {
        this.repository = repository;
    }

    @Override
    public void saveProducts(List<Product> products) {
        repository.saveAll(products);
    }

    @Override
    public List<ProductRatingResponse> computeRatings() {
        return repository.findAll()
                .stream()
                .map(p -> {
                    double avg = p.getRatings()
                            .stream()
                            .mapToInt(Rating::getRating)
                            .average()
                            .orElse(0.0);
                    return new ProductRatingResponse(p.getName(), avg);
                })
                .collect(Collectors.toList());
    }

    @Override  
    public List<Product> filterByDiscount(int discount) {
        return repository.findAll()
                .stream()
                .filter(p -> p.getDiscount_percentage() > discount)
                .collect(Collectors.toList());
    }

    @Override
    public List<Product> filterByPrice(int start, int end) {
        return repository.findAll()
                .stream()
                .filter(p -> p.getPriceAsInt() >= start && p.getPriceAsInt() <= end)
                .collect(Collectors.toList());
    }

    @Override
    public List<String> sortByPrice() { 
        return repository.findAll()
                .stream()
                .sorted(Comparator.comparingInt(Product::getPriceAsInt))
                .map(Product::getName)
                .collect(Collectors.toList());
    }
}

