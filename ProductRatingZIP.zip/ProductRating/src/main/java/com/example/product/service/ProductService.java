package com.example.product.service;



import com.example.product.dto.ProductRatingResponse;
import com.example.product.entity.Product;

import java.util.List;

public interface ProductService {

    void saveProducts(List<Product> products);

    List<ProductRatingResponse> computeRatings();

    List<Product> filterByDiscount(int discount);

    List<Product> filterByPrice(int start, int end);

    List<String> sortByPrice();
}
