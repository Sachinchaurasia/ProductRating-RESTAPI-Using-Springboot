package com.example.product.dto;

public class ProductRatingResponse {

    private String name;
    private double average_rating;

    public ProductRatingResponse(String name, double average_rating) {
        this.name = name;
        this.average_rating = average_rating;
    }

    public String getName() {
        return name;
    }

    public double getAverage_rating() {
        return average_rating;
    }
}

