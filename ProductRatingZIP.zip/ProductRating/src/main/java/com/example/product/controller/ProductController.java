package com.example.product.controller;



import com.example.product.dto.ProductRatingResponse;
import com.example.product.entity.Product;
import com.example.product.service.ProductService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class ProductController {

    private final ProductService service;

    public ProductController(ProductService service) {
        this.service = service;
    }

    @PostMapping("/rating/compute/")
    public ResponseEntity<List<ProductRatingResponse>> computeRatings(
            @RequestBody List<Product> products) {

        service.saveProducts(products);
        return ResponseEntity.ok(service.computeRatings());
    }

    @GetMapping("/filter/discount/{discount}")
    public ResponseEntity<List<Product>> filterByDiscount(@PathVariable int discount) {
        List<Product> result = service.filterByDiscount(discount);
        return result.isEmpty() ? ResponseEntity.badRequest().build() : ResponseEntity.ok(result);
    }

    @GetMapping("/filter/price/{start}/{end}")
    public ResponseEntity<List<Product>> filterByPrice(
            @PathVariable int start,
            @PathVariable int end) {

        List<Product> result = service.filterByPrice(start, end);
        return result.isEmpty() ? ResponseEntity.badRequest().build() : ResponseEntity.ok(result);
    }

    @GetMapping("/sort/price")
    public ResponseEntity<List<String>> sortByPrice() {
        return ResponseEntity.ok(service.sortByPrice());
    }
}

