package com.example.product.entity;



import javax.persistence.*;

@Entity
@Table(name = "ratings")
public class Rating {
	
	 @ManyToOne
	    @JoinColumn(name = "product_id")
	    private Product product;


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
	private int rating;
    private String rated_by;
    
    public int getRating() {
		return rating;
	}

	public void setRating(int rating) {
		this.rating = rating;
	}

	public String getRated_by() {
		return rated_by;
	}

	public void setRated_by(String rated_by) {
		this.rated_by = rated_by;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}



   
    // getters and setters
}

